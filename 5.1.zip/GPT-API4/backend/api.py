import json
import time
from pathlib import Path
from fastapi import APIRouter, HTTPException, UploadFile, File
from .config import (ALLOW_DELETE, DEFAULT_QUERY_FILE, EMBEDDING_MODEL, EXTRACTOR_MODEL, ONTOLOGY_FILE, TOPK)
from .converter import rows_to_quickstatements
from .models import ApproveRequest, ProposeRequest
from .extractor import ONTOLOGY, generate_proposal
from .state import PROPOSALS, SESSIONS, dedupe_rows, get_or_create_session, load_json_file, rows_delta

router = APIRouter(prefix="/api", tags=["api"])

def _as_row_list(rows):
    return [row for row in rows if isinstance(row, dict)] if isinstance(rows, list) else []

def _current_rows(session):
    return _as_row_list(session.get("current_kb_json", []))

def _require_input_text(input_text: str):
    if not input_text or not input_text.strip():
        raise HTTPException(status_code=400, detail="input_text is required")

def _require(mapping, key, detail):
    value = mapping.get(key)
    if value is None:
        raise HTTPException(status_code=404, detail=detail)
    return value

def _safe_generate_proposal(input_text: str, base_rows):
    try:
        return generate_proposal(input_text, base_rows)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))

async def _upload_json_array(file: UploadFile, out_name: str, array_error: str, success_message: str, on_success=None):
    raw = await file.read()
    try:
        data = json.loads(raw.decode("utf-8"))
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON file.")

    if not isinstance(data, list):
        raise HTTPException(status_code=400, detail=array_error)

    Path(out_name).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    if on_success is not None:
        on_success(data)

    return {
        "ok": True,
        "message": success_message,
        "saved_as": out_name,
        "original_filename": file.filename,
        "rows": len(data),
    }

def _get_base_rows_for_session(session):
    base_rows = session.get("base_kb_json")
    if isinstance(base_rows, list):
        return _as_row_list(base_rows)

    # Backward compatibility for sessions created before base_kb_json existed.
    try:
        loaded = load_json_file(DEFAULT_QUERY_FILE) if DEFAULT_QUERY_FILE.exists() else []
    except Exception:
        loaded = []
    loaded = _as_row_list(loaded)
    session["base_kb_json"] = loaded
    return loaded

@router.get("/health")
def api_health():
    return {
        "ok": True,
        "ontology_file": str(ONTOLOGY_FILE),
        "ontology_rows": len(ONTOLOGY.rows),
        "ontology_load_error": ONTOLOGY.load_error,
        "default_query_file_exists": DEFAULT_QUERY_FILE.exists(),
        "sessions": len(SESSIONS),
        "proposals": len(PROPOSALS),
        "extractor_model": EXTRACTOR_MODEL,
        "embedding_model": EMBEDDING_MODEL,
        "topk": TOPK,
        "allow_delete": ALLOW_DELETE,
    }

@router.get("/state/{session_id}")
def api_state(session_id: str):
    session = _require(SESSIONS, session_id, "Unknown session_id")
    base_rows = _get_base_rows_for_session(session)
    current_rows = _current_rows(session)
    delta_rows = rows_delta(base_rows, current_rows)
    return {
        "session_id": session_id,
        "base_kb_json": base_rows,
        "current_kb_json": current_rows,
        "delta_kb_json": delta_rows,
        "history_count": len(session["history"]),
        "created_at": session["created_at"],
    }

@router.get("/quickstatements/{session_id}")
def api_quickstatements(session_id: str, lang: str = "en"):
    session = _require(SESSIONS, session_id, "Unknown session_id")
    base_rows = _get_base_rows_for_session(session)
    current_rows = _current_rows(session)
    delta_rows = rows_delta(base_rows, current_rows)

    qs_text = rows_to_quickstatements(delta_rows, lang=lang)
    line_count = sum(1 for ln in qs_text.splitlines() if ln.strip())
    return {"session_id": session_id, "quickstatements": qs_text, "line_count": line_count}

@router.post("/upload-ontology")
async def api_upload_ontology(file: UploadFile = File(...)):
    return await _upload_json_array(
        file=file,
        out_name="ontology.json",
        array_error="Ontology must be a JSON array.",
        success_message="Ontology uploaded.",
        on_success=ONTOLOGY.load,
    )

@router.post("/upload-query")
async def api_upload_query(file: UploadFile = File(...)):
    return await _upload_json_array(
        file=file,
        out_name="query.json",
        array_error="query.json must be a JSON array.",
        success_message="Query uploaded.",
    )

@router.post("/propose")
def api_propose(req: ProposeRequest):
    _require_input_text(req.input_text)
    if ONTOLOGY.load_error:
        raise HTTPException(status_code=500, detail=f"Ontology load failed: {ONTOLOGY.load_error}")

    sid, session = get_or_create_session(req.session_id)

    base_rows = _current_rows(session)

    proposal = _safe_generate_proposal(req.input_text, base_rows)

    proposal["session_id"] = sid
    proposal["base_kb_json"] = base_rows
    return proposal

@router.post("/approve")
def api_approve(req: ApproveRequest):
    session = _require(SESSIONS, req.session_id, "Unknown session_id")
    proposal = _require(PROPOSALS, req.proposal_id, "Unknown proposal_id")

    approved_kb_json = req.edited_kb_json if req.edited_kb_json is not None else proposal["proposed_kb_json"]
    if not isinstance(approved_kb_json, list):
        raise HTTPException(status_code=400, detail="edited_kb_json must be a JSON array")

    existing_rows = _current_rows(session)
    merged_input = existing_rows + _as_row_list(approved_kb_json)
    session["current_kb_json"] = dedupe_rows(merged_input)

    session["history"].append({
        "proposal_id": req.proposal_id,
        "approved_at": time.time(),
        "diff": proposal["diff"],
        "reasoning_report": proposal["reasoning_report"],
    })

    return {
        "ok": True,
        "message": "Proposal approved and appended to session state (deduplicated).",
        "current_kb_json": session["current_kb_json"],
        "history_count": len(session["history"]),
    }

@router.get("/default-query")
def api_default_query():
    if not DEFAULT_QUERY_FILE.exists():
        return {"exists": False, "rows": []}
    try:
        rows = load_json_file(DEFAULT_QUERY_FILE)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Failed to read query file: {exc}")
    if not isinstance(rows, list):
        raise HTTPException(status_code=500, detail="query.json must be a JSON array")
    return {"exists": True, "rows": rows}
