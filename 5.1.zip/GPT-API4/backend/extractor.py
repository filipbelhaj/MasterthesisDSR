import json
import re
import time
import uuid
from copy import deepcopy
from typing import Any, Dict, List, Optional, Tuple
from .config import ALLOW_DELETE, EXTRACTOR_MODEL, TOPK, get_client
from .prompt import SYSTEM_PROMPT
from .state import PROPOSALS, canonical_row_key, dedupe_rows, norm

STATEMENT_FIELDS = (
    "item",
    "itemLabel",
    "property",
    "propertyLabel",
    "value",
    "valueLabel",
    "qualifierProperty",
    "qualifierPropertyLabel",
    "qualifierValue",
    "qualifierValueLabel",
)
CHANGE_ACTIONS = ("create", "edit", "link", "delete", "uncertain")

REQUIRED_OUTPUT_SCHEMA = {
    "proposed_rows": [{
        "item": "string URI or provisional NEW:entity_x",
        "itemLabel": "string",
        "property": "property URI from ontology",
        "propertyLabel": "string",
        "value": "URI or literal",
        "valueLabel": "optional string",
        "qualifierProperty": "optional qualifier property URI/string",
        "qualifierPropertyLabel": "optional string",
        "qualifierValue": "optional URI or literal",
        "qualifierValueLabel": "optional string",
    }],
    "changes": [{
        "id": "chg_001",
        "action": "create|edit|link|delete|uncertain",
        "entity_scope": "statement|entity",
        "target_ref": "existing URI or NEW:* or row-ref",
        "proposed_row_index": 0,
        "justification": "why this was proposed",
        "evidence": [{"snippet": "source snippet", "start_char": 0, "end_char": 20}],
        "confidence": 0.0,
        "review_flag": "optional flag or null",
    }],
}

_INLINE_WHITESPACE_RE = re.compile(r"[ \t\f\v]+")
_NEWLINE_PADDING_RE = re.compile(r"[ \t]*\n[ \t]*")
_MULTI_NEWLINE_RE = re.compile(r"\n{3,}")

def empty_ontology_index() -> Dict[str, Any]:
    return {
        "raw": [],
        "by_entity": {},
        "items": [],
        "properties": [],
        "label_to_entities": {},
        "property_labels": {},
    }

def _compact_evidence(evidence_list: Any) -> List[str]:
    return [
        snippet.strip()
        for snippet in (
            e.get("snippet") if isinstance(e, dict) else None
            for e in (evidence_list or [])
        )
        if isinstance(snippet, str) and snippet.strip()
    ]

def _statement_parts(row: Any) -> Tuple[str, Optional[str]]:
    if not isinstance(row, dict):
        return "Unknown item", None
    subject = row.get("itemLabel") or row.get("item") or "Unknown item"
    prop_label = row.get("propertyLabel") or row.get("property") or "unknown property"
    raw_value = row.get("valueLabel")
    if raw_value is None:
        raw_value = row.get("value")
    value_text = ("" if raw_value is None else str(raw_value)).replace("\n", " ").strip()
    if isinstance(raw_value, str) and len(value_text) > 260:
        value_text = value_text[:259].rstrip() + "…"
    statement = f"{prop_label} → {value_text}" if value_text else prop_label
    qprop = row.get("qualifierPropertyLabel") or row.get("qualifierProperty")
    qval = row.get("qualifierValueLabel") or row.get("qualifierValue")
    if qprop and qval:
        statement += f" [qualifier: {qprop} → {qval}]"
    return subject, statement

def _what_label(action: str, entity_scope: Any) -> str:
    if action == "create":
        return "Create entity" if entity_scope == "entity" else "Create statement"
    if action == "edit":
        return "Edit"
    if action == "link":
        return "Link to existing entity"
    if action == "delete":
        return "Delete"
    return "Needs review"

def _compact_entities(rows: List[Dict[str, Any]], limit: int) -> List[Dict[str, Any]]:
    return [{
        "entity": row.get("entity"),
        "entityLabel": row.get("entityLabel"),
        "entityDescription": row.get("entityDescription"),
    } for row in rows[:limit]]

def _existing_item_labels(base_rows: List[Dict[str, Any]]) -> List[str]:
    return sorted({
        row.get("itemLabel")
        for row in base_rows
        if isinstance(row, dict) and row.get("itemLabel")
    })[:500]

class OntologyStore:
    def __init__(self):
        self.rows: List[Dict[str, Any]] = []
        self.index: Dict[str, Any] = empty_ontology_index()
        self.compact_prompt_cache: Dict[str, Any] = {"properties": [], "items": []}
        self.load_error: Optional[str] = None

    def build_index(self, ontology_rows: List[Dict[str, Any]]) -> Dict[str, Any]:
        by_entity: Dict[str, Dict[str, Any]] = {}
        items: List[Dict[str, Any]] = []
        properties: List[Dict[str, Any]] = []
        label_to_entities: Dict[str, List[str]] = {}
        property_labels: Dict[str, str] = {}
        for row in ontology_rows:
            entity = row.get("entity")
            label = row.get("entityLabel")
            row_type = row.get("entityType")
            if entity:
                by_entity[entity] = row
            if label and entity:
                label_to_entities.setdefault(norm(label), []).append(entity)
            if row_type == "item":
                items.append(row)
            elif row_type == "property":
                properties.append(row)
                if label and entity:
                    property_labels[norm(label)] = entity
        return {
            "raw": ontology_rows,
            "by_entity": by_entity,
            "items": items,
            "properties": properties,
            "label_to_entities": label_to_entities,
            "property_labels": property_labels,
        }

    def load(self, ontology_rows: List[Dict[str, Any]]):
        self.rows = ontology_rows
        self.index = self.build_index(ontology_rows)
        self.compact_prompt_cache = {
            "properties": _compact_entities(self.index["properties"], 1000),
            "items": _compact_entities(self.index["items"], 800),
        }
        self.load_error = None

ONTOLOGY = OntologyStore()

def is_valid_property_uri(uri: Optional[str]) -> bool:
    if not uri:
        return False
    row = ONTOLOGY.index["by_entity"].get(uri)
    return bool(row and row.get("entityType") == "property")

def clean_statement_row(row: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    if row.get("item") is None or row.get("property") is None or row.get("value") is None:
        return None
    if not is_valid_property_uri(row.get("property")):
        return None
    return {k: v for k, v in ((field, row.get(field)) for field in STATEMENT_FIELDS) if v is not None}

def compact_ontology_for_prompt() -> Dict[str, Any]:
    return ONTOLOGY.compact_prompt_cache

def normalize_input_text(input_text: str) -> str:
    text = (input_text or "").replace("\r\n", "\n").replace("\r", "\n")
    text = _NEWLINE_PADDING_RE.sub("\n", text)
    text = _INLINE_WHITESPACE_RE.sub(" ", text)
    text = _MULTI_NEWLINE_RE.sub("\n\n", text)
    return text.strip()

def build_prompt_payload(input_text: str, base_rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    return {
        "task": "Extract ontology-valid Wikibase-like rows and a reasoning/change report",
        "source_text": normalize_input_text(input_text),
        "ontology": compact_ontology_for_prompt(),
        "existing_kb_preview_rows": base_rows[:TOPK],
        "existing_kb_item_labels_sample": _existing_item_labels(base_rows),
        "required_output_schema": REQUIRED_OUTPUT_SCHEMA,
    }

def call_extractor(input_text: str, base_rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    if ONTOLOGY.load_error:
        raise RuntimeError(f"Failed to load ontology: {ONTOLOGY.load_error}")
    payload = build_prompt_payload(input_text, base_rows)
    response = get_client().chat.completions.create(
        model=EXTRACTOR_MODEL,
        temperature=0.1, #Ändra till lägre om mer precision önskas, högre för mer kreativa förslag (Funkar bara med 5.4)
        response_format={"type": "json_object"},
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": json.dumps(payload, ensure_ascii=False)},
        ],
    )
    content = response.choices[0].message.content or "{}"
    try:
        return json.loads(content)
    except Exception as exc:
        raise RuntimeError(f"Extractor returned invalid JSON: {exc}\\nRaw: {content[:1000]}")

def validate_llm_output(llm_out: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], List[str]]:
    raw_rows = llm_out.get("proposed_rows", [])
    raw_changes = llm_out.get("changes", [])
    warnings: List[str] = []
    if not isinstance(raw_rows, list):
        raw_rows = []
        warnings.append("LLM output `proposed_rows` was not a list.")
    if not isinstance(raw_changes, list):
        raw_changes = []
        warnings.append("LLM output `changes` was not a list.")

    valid_rows: List[Dict[str, Any]] = []
    for idx, row in enumerate(raw_rows):
        if not isinstance(row, dict):
            warnings.append(f"proposed_rows[{idx}] ignored (not an object)")
            continue
        cleaned = clean_statement_row(row)
        if not cleaned:
            warnings.append(f"proposed_rows[{idx}] ignored (missing fields or invalid property)")
            continue
        valid_rows.append(cleaned)
    return dedupe_rows(valid_rows), raw_changes, warnings

def merge_proposal_into_base(base_rows, proposal_rows, changes):
    base_copy = deepcopy(base_rows)
    base_keys = {canonical_row_key(row) for row in base_copy if isinstance(row, dict)}
    delete_keys = set()
    if ALLOW_DELETE:
        for change in changes:
            if not isinstance(change, dict) or change.get("action") != "delete":
                continue
            idx = change.get("proposed_row_index")
            if isinstance(idx, int) and 0 <= idx < len(proposal_rows):
                delete_keys.add(canonical_row_key(proposal_rows[idx]))

    kept_rows = [row for row in base_copy if canonical_row_key(row) not in delete_keys]
    added_rows = []
    for row in proposal_rows:
        row_key = canonical_row_key(row)
        if row_key not in base_keys:
            kept_rows.append(row)
            added_rows.append(row)
    return {
        "merged_rows": dedupe_rows(kept_rows),
        "diff": {"added_rows": added_rows, "edited_rows": [], "deleted_rows": []},
    }

def normalize_reasoning_report(raw_changes, proposal_rows, validation_warnings):
    counts = {action: 0 for action in CHANGE_ACTIONS}
    changes_out = []
    for change in raw_changes:
        if not isinstance(change, dict):
            continue
        action = change.get("action", "uncertain")
        if action not in counts:
            action = "uncertain"
        counts[action] += 1

        idx = change.get("proposed_row_index")
        proposed_row = proposal_rows[idx] if isinstance(idx, int) and 0 <= idx < len(proposal_rows) else None
        evidence = change.get("evidence", [])
        if not isinstance(evidence, list):
            evidence = []
        subject, statement_preview = _statement_parts(proposed_row)
        changes_out.append({
            "what": _what_label(action, change.get("entity_scope", "statement")),
            "subject": subject,
            "statement": statement_preview,
            "why": ("" if change.get("justification", "") is None else str(change.get("justification", ""))).strip(),
            "evidence": _compact_evidence(evidence),
            "confidence": change.get("confidence", 0.0),
            "needs_review": change.get("review_flag"),
        })
    return {
        "summary": {
            "creates": counts["create"],
            "edits": counts["edit"],
            "links": counts["link"],
            "deletes": counts["delete"],
            "uncertain": counts["uncertain"],
            "validation_warnings": len(validation_warnings),
        },
        "validation_warnings": validation_warnings,
        "proposed_changes": changes_out,
    }

def generate_proposal(input_text: str, base_rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    llm_out = call_extractor(input_text=input_text, base_rows=base_rows)
    proposal_rows, raw_changes, warnings = validate_llm_output(llm_out)
    merged = merge_proposal_into_base(base_rows, proposal_rows, raw_changes)
    reasoning = normalize_reasoning_report(raw_changes, proposal_rows, warnings)
    proposal_id = f"prop_{uuid.uuid4().hex[:10]}"
    proposal = {
        "proposal_id": proposal_id,
        "proposed_kb_json": merged["merged_rows"],
        "reasoning_report": reasoning,
        "diff": merged["diff"],
        "proposal_rows_only": proposal_rows,
        "created_at": time.time(),
    }
    PROPOSALS[proposal_id] = proposal
    return proposal
